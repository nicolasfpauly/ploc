# PLOC 0.7.0-rc1

**Requires Hundekraft 3.3** on the original OP-1. This is a preview. Mac tests passed; hardware testing is pending.

1. In the matching Hundekraft Workshop, import `ploc.knl`. Review the update. If upgrading from PLOC 0.6.2, replace the synth and remove the old PLOCCTRL entry if present.
2. If you do not already have the eight presets, switch to DISK mode after installing the plugin. Copy the included `ploc` folder into the OP-1 drive’s `synth/` folder. Eject and let it sync.

[Source, build instructions and changelog](https://github.com/nicolasfpauly/ploc).
