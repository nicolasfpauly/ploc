# PLOC presets for Hundekraft

Eight sounds for the original OP-1 with PLOC installed: flow eau, flow voile, goutte, lac calme, perle fine, pluie vive, pouic air, and ruissel. The presets retain their saved effect settings; those effects need to be present in your Hundekraft build.

After installing the plugins, connect the OP-1 over USB and press **Shift + COM**, then **DISK (T3)**. Copy the extracted `ploc` folder from `synth/` into the OP-1 drive’s `synth/` folder. Eject the OP-1, let it finish syncing, then use **Shift + 1–8** to browse the sounds. If you already have the eight PLOC presets, skip this step to avoid duplicates. See the [OP-1 disk mode guide](https://teenage.engineering/guides/op-1/original/song-rendering-and-connectivity#13.5-disk-mode).

[Plugin install and source](https://github.com/nicolasfpauly/ploc)
